package com.firebow.util;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Block input trong lúc mod đang thực hiện action.
 * Pattern từ BOOST-FPS: dùng named owners thay vì boolean đơn.
 * Nhiều hệ thống có thể block độc lập, unblock khi xong.
 */
public final class InputBlocker {
    private InputBlocker() {}

    private static final Set<String> OWNERS = ConcurrentHashMap.newKeySet();

    public static void block(String owner)   { OWNERS.add(owner); }
    public static void unblock(String owner) { OWNERS.remove(owner); }
    public static boolean isBlocked()        { return !OWNERS.isEmpty(); }
}
